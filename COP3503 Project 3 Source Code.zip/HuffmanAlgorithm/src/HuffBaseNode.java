public interface HuffBaseNode {
	public boolean isLeaf();
	public int weight();
}